# Freelance Marketplace MVP

## Run locally (Windows PowerShell)
1. Open this folder in VS Code.
2. In Terminal, run `py -m venv venv`.
3. Activate: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` then `.env\Scripts\Activate.ps1`.
4. Install: `py -m pip install -r requirements.txt`.
5. Run migrations: `py manage.py makemigrations marketplace` then `py manage.py migrate`.
6. Create admin: `py manage.py createsuperuser`.
7. Start: `py manage.py runserver`; open http://127.0.0.1:8000/.

This is an academic MVP starter, not a production payment or real-time chat system. Payment records are status tracking only; messaging is stored-message groundwork. Configure production security and test all workflows before deployment.
