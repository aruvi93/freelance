from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from .models import Project, Proposal

def home(request):
    projects = Project.objects.filter(status='open').order_by('-created_at')
    return render(request, 'marketplace/home.html', {'projects': projects})

def register(request):
    form = UserCreationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user)
        return redirect('home')
    return render(request, 'marketplace/register.html', {'form': form})

def user_login(request):
    form = AuthenticationForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        login(request, form.get_user())
        return redirect('home')
    return render(request, 'marketplace/login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('home')

@login_required
def project_create(request):
    if request.method == 'POST':
        Project.objects.create(client=request.user, title=request.POST['title'],
            description=request.POST['description'], budget=request.POST['budget'])
        return redirect('home')
    return render(request, 'marketplace/project_form.html')

@login_required
def proposal_create(request, project_id):
    project = get_object_or_404(Project, id=project_id, status='open')
    if request.method == 'POST':
        Proposal.objects.create(project=project, freelancer=request.user,
            cover_letter=request.POST['cover_letter'], bid_amount=request.POST['bid_amount'])
        return redirect('home')
    return render(request, 'marketplace/proposal_form.html', {'project': project})
