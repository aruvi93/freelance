from django.contrib import admin
from .models import Profile, Project, Proposal, WorkItem, Message, PaymentRecord, Review
admin.site.register([Profile, Project, Proposal, WorkItem, Message, PaymentRecord, Review])
