from django.urls import path
from . import views
urlpatterns = [
 path('', views.home, name='home'),
 path('register/', views.register, name='register'),
 path('login/', views.user_login, name='login'),
 path('logout/', views.user_logout, name='logout'),
 path('projects/new/', views.project_create, name='project_create'),
 path('projects/<int:project_id>/propose/', views.proposal_create, name='proposal_create'),
]
